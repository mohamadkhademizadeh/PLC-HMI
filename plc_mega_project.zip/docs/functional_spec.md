# Functional Specification — Beverage Bottling & Packaging Line (excerpt)

This document is the functional design for the automated bottling & packaging line.
It follows ISA-88 modularity and ISA-95 naming conventions. The system contains:

- Areas: Process, Packaging, Conveyance, Utilities
- Units: Mix tank, Pasteurizer, Filler Monoblock, CIP Skid
- Equipment Modules & Control Modules (CM_*) implemented as reusable FBs

The repository contains ST function blocks for motor, VFD, valve, conveyor zone, and level control.
See `/fb/` for implementations and `/io/` for sample tag/I-O lists.
